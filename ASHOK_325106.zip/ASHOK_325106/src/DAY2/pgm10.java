package DAY2;

public class pgm10 {
	public static int add(int a,int b)
	{
		return a+b;
	}
	public static void main(String arg[])
	{
		int a,b=10,c=15;
		a=add(5,9);
		System.out.println(a);
		a=add(b,c);
		System.out.println("sum of "+b+" and "+c+" = "+a);
	}

}
