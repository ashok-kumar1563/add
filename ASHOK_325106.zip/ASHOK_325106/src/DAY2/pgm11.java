package DAY2;

public class pgm11 {
public static boolean isPrime(int n)
{
    boolean b=true;
    for(int i=2;i<=n/2;i++)
    {
    	if(n%i==0)
    	{
    		b=false;
    		return b;
    	}
    }
    return b;
}
public static void main(String arg[])
{
int i=0,j=2,sum=0;
while(i<10)
{
if(isPrime(j))
{
	i++;
	System.out.print(j+" ");
	sum=sum+j;
	

}
j++;
}
System.out.println();
System.out.println("sum ="+sum);
}
}
