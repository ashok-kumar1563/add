package DAY1;

public class pgm6 {

}
